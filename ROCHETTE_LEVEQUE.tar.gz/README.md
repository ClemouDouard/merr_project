# PROJECT REGULARIZATION METHODS

This is a school project.

## Dataset

The dataset is based on medical data, and the goal is to predict whether or not a patient will die.

https://www.kaggle.com/datasets/joebeachcapital/support2

https://hbiostat.org/data/repo/supportdesc